% Aufgabe1c.m
% 11.05.2024
clc, clearvars, close all

